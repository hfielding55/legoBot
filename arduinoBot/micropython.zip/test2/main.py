#!/usr/bin/env pybricks-micropython
from pybricks.hubs import EV3Brick
from pybricks.ev3devices import (Motor, TouchSensor, ColorSensor,
                                 InfraredSensor, UltrasonicSensor, GyroSensor)
from pybricks.parameters import Port, Stop, Direction, Button, Color
from pybricks.tools import wait, StopWatch, DataLog
from pybricks.robotics import DriveBase
from pybricks.media.ev3dev import SoundFile, ImageFile


# This program requires LEGO EV3 MicroPython v2.0 or higher.
# Click "Open user guide" on the EV3 extension tab for more information.


# Create your objects here.
ev3 = EV3Brick()
input = 0

#motors
motor_A = Motor(Port.A)
motor_D = Motor(Port.D)

#sensors
sensor = TouchSensor(Port.S1)

def takeInput():
    count = 0
    while sensor.pressed(): #arduino holds high for a specific period of time
        count += 1
        wait(50) #checks every 50 ms until it goes low
    return count

while True:
    input = 0
    if (sensor.pressed() == True): #detects when arduino goes high
        input = takeInput()
    if (input > 0):
        angleA = 245 * (input - 3) #makes angle -45, 0 or 45 on the physical robot
        motor_D.run_angle(-400, angleA, Stop.HOLD, True) #turn crane
        motor_A.run_angle(300, 380, Stop.HOLD, True) #lower crane
        wait(1000) 
        motor_A.run_angle(300, -380, Stop.HOLD, True) #retract crane
        motor_D.run_angle(400, angleA, Stop.HOLD, True) #return to forward position
    